/*=============================================================================
 util.ts - general utility functions

 - For debugging, attach "border border-pink-400" to the c_base.
 - Regex for the function call and the whole arguments:
    (c[C|L]0?o?)\(\s*([^)]+?)\s*\)
 - Keep this utility module with no dependencies

 @author  TA_金秀
=============================================================================*/

const DEVELOPMENT_MODE: boolean =
  !process.env.NODE_ENV ||
   process.env.NODE_ENV === 'development';

export function isDev() {
  return DEVELOPMENT_MODE;
}

export function dbg(text: string) {  // debug text
  return DEVELOPMENT_MODE ? text : null;
}

export type TBrowserKind = 'chrome'|'safari'|'firefox'|'unknown';

export function addIf(
  cnd_if: Ifable, // if condition
  c_then: string  // then statement
) {
  return cnd_if ? c_then : '';
}

/**
 * 'block' may be not required; w-full not works with block
 */
export const showIf = (show: Ifable) => show ? 'block' : 'hidden';
export const hideIf = (hide: Ifable) => showIf(!hide);

// ----------------------------------------------------------------------------
// className Utilities - Purposes (mainly for tailwindcss' long list of classNames)
// ----------------------------------------------------------------------------
// 1. Combine list of strings, no need to care for the delimeter ' ' between strings.
// 2. Conditional expressions such as {mobile && 'ml-4'} can be seamlessly added.
//    (React className string cannot be concatenated with null or false expressions.)
// 3. Using the Object { className: ... } and the spread operator (...), "className=" can be removed.

type TCondClassF<T = TClassName> = (  // call signature
  c_base:  TClassName,   // base classname
  cnd_if:  Ifable,       // if the condition met
  c_then:  TClassName,   // concatenate
  c_else?: TClassName    // (optional) otherwise
) => T;

/**
 * className Conditional
 * Concatenate class names only if the provided condition is met
 * and return the className object so that it can be used with the spread syntax
 * - className={cC()}  --->  {...cCo()}
 * @param c_base base string
 * @param cnd_if condition if
 * @param c_then then case
 * @param c_else else case
 * @returns result string | undefined
 */
export const cC: TCondClassF = (   // class with options (if-then-else)
  c_base, cnd_if, c_then, c_else
) => {
  const c_prefix = c_base ? c_base + ' ' : '';  // handle c_base Nullish case
  // const c_prefix = "border border-pink-400 " + (c_base ? c_base + ' ' : '');  // DEBUG
  if (cnd_if) return (c_prefix + c_then);
  if (c_else) return (c_prefix + c_else);  // if the third option was given
  return              c_base || '';
}

/**
 * className Conditional object
 */
export const cCo: TCondClassF<IClassNameObj> = (   // class with options (if-then-else)
  c_base, cnd_if, c_then, c_else
) => ({ className: cC(c_base, cnd_if, c_then, c_else) });

/**
 * className Conditional 0(no base) object
 */
export const cC0o = (
  cnd_if:  Ifable,      // if the condition met
  c_then:  TClassName,  // concatenate
  c_else?: TClassName   // (optional) otherwise
): IClassNameObj => ({ className: cnd_if ? c_then : c_else });

/**
 * class List
 * className={"m-1 text-gray-400 " + (cls || "")} can be written as:
 * className={cL('m-1', 'text-gray-400', cls)}
 * just boolean true value is filtered by the input type Maybe<string|false>
 */
export function cL(
  ...clss: readonly TClassName0[]  // rest parameters, list of classNames allowing null or boolean
): TClassName {
  // clss.push("border border-pink-400");  // DEBUG, remove 'readonly'
  return clss.reduce((cum, a) => a // check this add
    ? cum               // if valid previous (cumulative) string
      ? cum + ' ' + a   //   concatenate with the delimeter ' '
      : a               // no valid previous string
    : cum               // no valid a
  ) || undefined;       // Only undefined is allowed in nullish expressions in React
}

/**
 * class List with If (show or hide condition)
 */
export function cLIf(
  cnd_show: Ifable,        // only show the block if the condition met
  ...clss:  TClassName0[]  // rest parameters, list of classNames allowing null or boolean
): TClassName {
  return cL(showIf(cnd_show), ...clss);
}

/**
 * class List object: to omit 'className=' using spread attributes
 * className=""
 * {...cLo('m-1', 'text-gray-400', cls)}
 */
export function cLo(
  ...clss: TClassName0[]
): IClassNameObj {
  return { className: cL(...clss) };
}

/**
 * class List object with If (show or hide condition), only works for tailwind classes
 */
export function cLoIf(
  cnd_show: Ifable,
  ...clss:  TClassName0[]
): IClassNameObj {
  return { className: cLIf(cnd_show, ...clss) };
}

// ----------------------------------------------------------------------------
/**
 * conditional string concatenation (cL's string version, no classNames)
 * The difference with cL is just the separating space between strings.
 */
export function cS(
  ...lstr: Maybe<string | false>[]  // rest parameters, list of strings allowing null or boolean
): stringU {
  return lstr.reduce((cum, a) => a  // check this add
    ? cum          // if valid previous (cumulative) string
      ? cum + a    //   concatenate with no delimeter
      : a          // no valid previous string
    : cum          // no valid a
  ) || undefined;  // Only undefined is allowed in nullish expressions in React
}
// ----------------------------------------------------------------------------

/**
 * number to leadingZero string
 * or use n.toString().padStart(2, "0");  // ES6
 */
export const lZ = (n: number) =>
  (n < 10)
    ? '0' + n
    : n.toString();  // leading Zero making a two digit number string

// const callifdef = (f, arg) => if (f && typeof f === "function") f(arg);

export function toggleValue<T = string>(val: T, a: T, b: T): T {
  return (val === a) ? b : a;
}

/**
 * for use as <a {...OPEN_NEW_WINDOW}>
 */
export const OPEN_NEW_WINDOW = {
  target: "_blank",
  rel:    "noopener noreferrer"
};

/**
 * Simple test version
 * * https://stackoverflow.com/questions/9847580/how-to-detect-safari-chrome-ie-firefox-and-opera-browser
 * @returns browser_name Chrome, Safari, Firefox, unknown
 */
export const detectBrowser = (): TBrowserKind => {
  const ua = navigator.userAgent.toLowerCase();
  if (ua.indexOf('safari') !== -1)
    return (ua.indexOf('chrome') > -1) ? 'chrome' : 'safari';
  if (ua.indexOf('firefox'))
    return 'firefox';
  return 'unknown';
}
// navigator.userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"

/**
  * Plain text in template string to HTML
  */
export const replaceCRtoHTML = (text: string) => text.replace(/\r?\n|\r/g, "<br/>");

/**
  * Template string inserts CR for each line. To remove them use this function.
  */
export const removeCR = (html: string) => html.replace(/\r?\n|\r/g, "");

/**
 * set CSS variables
 * @param css array of css strings
 */
export const setCssVar = (css: string[]) => {
  const root = document.getElementsByTagName('html')[0];
  root.style.cssText = css.join(';');
}
