# REFMa (Railway Electrical Facilities Maintenance Management System) 鉄道電気設備保守管理システム フロントエンド化デモ
### 2024年（令6）6月

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default {
  // other rules...
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: ['./tsconfig.json', './tsconfig.node.json'],
    tsconfigRootDir: __dirname,
  },
}
```

- Replace `plugin:@typescript-eslint/recommended` to `plugin:@typescript-eslint/recommended-type-checked` or `plugin:@typescript-eslint/strict-type-checked`
- Optionally add `plugin:@typescript-eslint/stylistic-type-checked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and add `plugin:react/recommended` & `plugin:react/jsx-runtime` to the `extends` list

### ASP.NET Web FormsのMVC化、ASP.NET Coreとの共存関係調査 2024/05/17(金)～24(金)
### 『検査設備台帳』SPA(Single Page App)版デモ2024/05/27(月)～06/12(水)
1. 列ソート
2. 絞り込み検索、ハイライト
3. 表示レベル
4. ページング
5. 列幅調整
6. markup、縮約
7. マルチ検索語
8. ポップアップ、スライド子画面

### 『長期作業計画表』SPA版デモ 2024/06/13(木)～/26(水)

1. SQLクエリ結果のCSVデータをHTTP/GETで受信、内部で画面表示用に変換
  - 長期作業計画検査一覧クエリ(SelectInspectionDataQuery.sql)
  - 予実データ１(SelectPrePlanDateDataQuery.sql)
  - 予実データ２(SelectPlanDateDataQuery.sql)
  - マスタ：所管区、設備カテゴリ、定期ひな型

2. 絞り込み検索、マルチ検索語
　- 画面表示項目(計画策定に関する備考等)＋非表示項目（補足、備考、変更履歴等）
  - ターゲット設定ボタン付きの検索語入力コントロール

3. ソート、列幅調整、ページング
　- 『検査設備台帳』SPA版同等の機能、通信を介さず迅速に画面更新が行われること

4. 「検索条件設定」ポップアップ
  - 選択項目（実施主体、実施基準対象検査、廃止／休止、直営／保守契約、作業時間帯）

5. 列固定ON/OFF、予実データ(年間計画)パートの拡張表示

※  予実データのSVGアイコン表示
  - 0.5か月周期
  - 許容期間
  - 実施予定月の移動処理
  - Tooltip

※  コード入力補助ポップアップ
  - 設備カテゴリ、定期検査ひな型台帳

※  高度な検索条件
  - OR、EXCLUDEの指定

※  タグ付け一覧管理
  - Bookmark
