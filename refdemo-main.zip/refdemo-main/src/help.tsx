/**
 * @file    REFMaデモ版 Help
 * @version 1.0.0
 * @Date    2024/06/22
 * @author  TA_金秀
 */

const FEFeatures = () => {
  const head =
    {title: '機能',        desc: 'デモ版の実装内容(遅延のないレスポンシブUI)',};
  const body = [
    {title: '列ソート*',   desc: '表形式のデータに列ソート機能を組み込む(◇ ▲ ▼)',},
    {title: '列幅調整',    desc: '列数が多い表の列幅をマウスで調整可能にする',},
    {title: '表示レベル',  desc: '列毎に表示レベルを設定 ⇒ 簡単に表示/非表示の切り替え',},
    {title: 'ページング*', desc: '自動ページング、インデクス生成、行数/頁設定',},
    {title: '検索*',       desc: 'タグ入力・編集、マルチキーワード支援、色分けハイライト、markup等 ⇒ 高度な検索条件 ※後の課題',},
    {title: 'UI要素',      desc: 'ポップアップ、スライド子画面、自動消滅通知',},
    {title: 'データ通信',  desc: 'REST APIでSQLクエリー結果のcsvを受信、データ加工して表示',},
    {title: 'グリッド化※', desc: '従来のSVGやTable形式をCSS Grid化して… ⇒ ※時間不足で着手できず',},
  ];
  const clsTitle = (title: string) => {
    const s = title.slice(-1);
    let attr = '';
    switch (s) {
      case '*': attr = 'text-red-500';  break;
      case '※': attr = 'text-blue-500'; break;
      default:  attr = 'text-black';
    }
    return ({ className: attr });
  }
  return (
    <div className="mt-4 mx-8">
      <h1 className="text-center font-bold">
        フロントエンド化デモ版の特徴
      </h1>
      <table className="min-w-full divide-y divide-gray-300">
        <thead>
          <tr className="bg-slate-200">
            <th scope='col' className='py-2 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-3'>
            </th>
            <th scope='col' className='py-2 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-3'>
              {head.title}
            </th>
            <th scope="col" className="px-3 py-2 text-left text-sm font-semibold text-gray-900">
              {head.desc}
            </th>
          </tr>
        </thead>
        <tbody className="bg-white">
          {body.map((r, i) =>
            <tr key={r.title} className="even:bg-gray-50 border-slate-400 first:border-t-2 last:border-b-2">
              <td className="whitespace-nowrap py-1 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-3">
                {i+1}
              </td>
              <td className="whitespace-nowrap py-1 pl-4 pr-3 text-sm font-semibold font-medium text-gray-900 sm:pl-3">
                <span {...clsTitle(r.title)}>{r.title}</span>
              </td>
              <td className="whitespace-nowrap px-3 py-1 text-sm text-gray-500">
                {r.desc}
              </td>
            </tr>)}
        </tbody>
      </table>
      <p className="my-4 text-blue-700">
        ※ ASP.NET Framework 4.8(Web Forms⇒一部MVC化)基盤のレガシー環境にて、最新フロントエンドのSPAを共存させる課題
        <br />
        <span className="text-red-600 text-sm">
          ⇒ 製造・デプロイ過程における制約はあるものの組み合わせ可能であることを確認!!😲</span>
        <br />
        <span className="text-black text-sm">
          ⇒ 最大のメリットは、これらの機能を本体のシステムから切り離して(decoupling)、抽象化によって部品化が可能になり、保守性はもちろん、後の画面開発工程が大幅に短縮できること。
          <span className="text-blue-800 text-xs">
            ※ デモ版では、画面共通要素の部品化と再利用性を極めるため、React Hooksとfunctional技法を主に使用。CSSは、REFMaと互換性の検証が必要なため、フレームワークの使用を控える。
            実際、複数画面に適用することによって、ビジネスデータの分離、基本機能の共通化、部品化まで実証済み。
          </span>
        </span>
        <br />
        <br />
        <span className="text-black text-sm">
          ● 開発環境：React 18.3(Hooks,functional)/TypeScript 5.5, pure CSS + TailwindCSS 3.4, vite 5.3, yarn 1.22, node.js(試験用のファイルサーバ), Ubuntu 22.04.3LTS/WSL 2(or MacOS)
        </span>
      </p>
    </div>);
}

const Help = () => {
  const spaIds = [
    {id: 'ieq', name: '検査設備台帳',   en: 'Inspection Equipment'},
    {id: 'ins', name: '検査台帳',       en: 'Inspection'},
    {id: 'ltp', name: '長期作業計画表', en: 'Long-Term Plan'},
  ];
  const SCRIPT_IN_REFMA_VIEW =
`<head>
  <script id="spa_id" type="application/json">{"id":"ltp"}</script>
  <script type="module" crossorigin src="~/Content/demo/spa.js"></script>
  <link rel="stylesheet" crossorigin href="~/Content/demo/spa.css">
  ...
</head>
<div id='root'></div>   <!-- SPAが組み込まれる個所 -->
`
  return (
    <div className='h-svh font-mono overflow-auto'>
      <h1 className='text-lg text-center bg-slate-200'>REFMaフロントエンドSPA化デモ版(2024年6月)</h1>
      <div className="mx-8">
        <h2 className='text-red-600'>画面ID(spa_id)の取得失敗!</h2>
        <h2 className='text-sm text-blue-700 max-w-prose'>※spa_idは、このSPA(Single Page App)が起動時に表示する画面を選択するために参照するidです。DEBUGモードでは、URLから参照するため下記のようにURLパラメータを渡すことで画面が選択できます。</h2>
        <h2 className='font-bold'>《spa_id一覧》</h2>
        <ul className='list-disc ml-4'>
        {spaIds.map(s =>
          <li key={s.id}>
            <span className='font-bold text-blue-500 mr-2'>{s.id}</span>
            <span className='text-black mr-2'>{s.name}</span>
            <span className='text-sm text-blue-800'>{s.en}</span>
          </li>)}
        </ul>
        <p>例）
          <a className="underline" href='http://localhost:5173/?id=ltp'>
            http://localhost:5173/
            <span className='font-bold text-red-500'>?id=</span>
            <span className='font-bold text-blue-500'>ltp</span>
          </a>
        </p>
        <p>※なお、DEBUGモードではCORSのため専用のfileserverが必要となります。(node.jsのソース提供)</p>
        <h2 className='mt-4 font-bold'>REFMa内での埋め込み方</h2>
        <h2 className='text-sm text-blue-700 max-w-prose'>※全ての画面が一つのjsファイルに統合されている。以下、長期作業計画(ltp)の例。Viewのcshtmlファイル。</h2>
        <pre className='p-4 text-yellow-100 bg-slate-900'>{SCRIPT_IN_REFMA_VIEW}</pre>
      </div>
      <FEFeatures />
      <div className="mx-8 mb-12 text-right">以上</div>
    </div>);
}

export default Help;
