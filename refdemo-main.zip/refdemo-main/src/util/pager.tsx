/**
 * @file    Abstraction of paging
 * @version 0.2
 * @Date    2024/06/20
 * @author  TA_金秀
 **/

import { type PropsWithChildren, useState, } from 'react';
import { lZ, } from 'util/util';
import type { TDataLine } from './loader';
import 'styles/pager.css';

interface IPagerParams {
  page:          number;
  setPage:       (page: number) => void;
  maxPage:       number;
  rowsPerPages?: number[];
  rowsPage:      number;
  setRowsPage:   (rp: number) => void;
  maxRow:        number;
}

export const usePager = (
  fRes:          TDataLine[], // data source
  rPP:           number=100,  // rows/page
  rowsPerPages?: number[],    // selectable list of rows/page: use only if it set
) => {
  const [page,     setPage]     = useState(1);
  const [rowsPage, setRowsPage] = useState(rPP);   // rows per page

  const maxPage = Math.ceil(fRes.length/rowsPage);
  if (page !== 1 && maxPage && page > maxPage)  // be careful for too many renders
    setPage(1);
  return ({
    fResPaged:    fRes.slice((page-1)*rowsPage, page*rowsPage),
    page,
    setPage,
    maxPage,
    rowsPerPages,
    rowsPage,
    setRowsPage,
    maxRow:       fRes.length,
  });
}

const MAX_ALLOWED_PAGES = 30;
export const Pager = ({
  page, setPage, maxPage,
  rowsPerPages, rowsPage, setRowsPage, maxRow, children}: PropsWithChildren<IPagerParams>
) => {
  const clsPg = (checkPage: number) =>
    ({...(page === checkPage && {className: 'inactive'})});
  return (
    <div className='PageControls'>
      {children}
      {rowsPerPages &&
        <label>
          ■
          <select value={rowsPage} onChange={ev => setRowsPage(Number(ev.target.value))}>
            {rowsPerPages.map((op, k) =>
              <option key={k}
                disabled={(k > 0 && maxRow < rowsPerPages[k-1])
                      || (Math.ceil(maxRow/op) > MAX_ALLOWED_PAGES)}
              >
                {op}
              </option>)}
          </select>
          行/頁
        </label>}
      <div className='PagesIndex'>
        <a {...clsPg(1)} onClick={_ => setPage(1)}>{`≪  `}</a>
        <a {...clsPg(1)} onClick={_ => (page > 1) && setPage(page-1)}>{`< `}</a>
        {Array.from({length: maxPage}, (_, i) => i+1).map(p =>
          <a key={p}
            {...((p === page) && {className: 'cur'})}
            onClick={_ => setPage(p)}
          >
            {lZ(p)}
          </a>)}
        <a {...clsPg(maxPage)} onClick={_ => (page < maxPage) && setPage(page+1)}>{` >`}</a>
        <a {...clsPg(maxPage)} onClick={_ => setPage(maxPage)}>{` ≫`}</a>
      </div>
    </div>
  );
}
