/**
 * @file    Tags
 * @version 1.1.0
 * @Date    2024/06/10
 * @author  TA_金秀
 */
import type { ChangeEventHandler, HTMLAttributes, KeyboardEventHandler,
  PropsWithChildren,
} from 'react';
import { FC, useState, } from 'react';
import icoXCircle from 'Images/x-circle.svg';
import icoSearch  from 'Images/Icons/search.svg';
import 'styles/search.css';

export interface ITagsInputProps {
  tags:      string[];
  setTags:   (list: string[]) => void;
  matchCnt?: number;
  maxTags?:  number;
}

/**
 * Tags Input Editor
 * +---------------------------------------+
 * | [tag1(x)] [tag2(x)] [tag3(x)] tag4    |
 * +---------------------------------------+
 * Show border for the whole list not on the real input field
 */
export const TagsInput = ({ children, tags, setTags, matchCnt, maxTags=7}:
  PropsWithChildren<ITagsInputProps>
) => {
  const [noCompo,  setNoCompo]  = useState(true);   // not in IME composition mode
  const [value,    setValue]    = useState('');
  const [isKeyRel, setIsKeyRel] = useState(false);  // is key released
  const delimiters = new RegExp(/[\s,;|、；]+/);
  const KEY_ENTER = 'Enter';
  const KEY_ESC   = 'Escape';
  const KEY_BKSP  = 'Backspace';

  const onChange: ChangeEventHandler<HTMLInputElement> = (ev) => {
    if (tags.length >= maxTags)
      return;
    setValue(ev.target.value);
  }
  const onCompositionStart = () => setNoCompo(false);
  const onCompositionEnd   = () => setNoCompo(true);
  const isUniqueTag = (candidate: string) =>
    !tags.some(tag => tag.toLowerCase() === candidate.toLowerCase());
  const onKeyDown: KeyboardEventHandler<HTMLInputElement> = (ev) => {
    const tVal = value.trim();
    if (tVal.length) {
      if (noCompo) {
        if (ev.key === KEY_ENTER) {  // ev.key === ' ' || 
          ev.preventDefault();
          addTag(tVal)
        } else if (ev.key === KEY_ESC) {
          setValue('');
        }
      }
    } else {  // empty input field
      if (tags.length) {
        if (noCompo && (ev.key === KEY_ENTER)) {
          // use current tags
        } else if (isKeyRel) {
          if ( ev.key === KEY_ESC
            || ev.key === KEY_BKSP) {
            ev.preventDefault();
            const tagsCopy = [...tags];  // for immutability
            const poppedTag = tagsCopy.pop();  // remove the last item
            setTags(tagsCopy);
            if (poppedTag && (ev.key === KEY_BKSP))
              setValue(poppedTag);  // put tag in the edit field
          }
        }
      }
    }
    setIsKeyRel(false);
  }

  const onKeyUp = () => setIsKeyRel(true);
  const deleteTag = (index: number) =>
    setTags(tags.filter((_tag, i) => i !== index));
  const onSearchButton = () => {
    if (!noCompo)
      return;
    const tVal = value.trim();
    if (tVal.length)
      addTag(tVal);
  }

  const addTag = (tVal: typeof value) => {
    if (tags.length >= maxTags)
      return;
    if (delimiters.test(tVal)) {  // possible input when copy&pasted
      let aValue = [...new Set(tVal.trim().split(delimiters))]
                      .filter(t => t && isUniqueTag(t));
      if (tags.length + aValue.length >= maxTags)
        aValue = aValue.slice(0, maxTags - tags.length);
      setTags([...tags, ...aValue]);
    } else if (isUniqueTag(tVal)) {
      setTags([...tags, tVal]);
    }
    setValue('');
  }
/*
      <button type='button' className='target' onClick={_ => alert('target')}>
        TARGET
      </button>
*/
  return (
    <div className='tagsCont' {...(matchCnt !== undefined && { 'data-c': matchCnt })}>
      {children}
      {tags.map((tag, i) =>
        <TagItem key={tag} className='tagItem' data-i={i}
          onDeleteCB={() => deleteTag(i)}>{tag}</TagItem>)}
      <input className='tagInput'
        placeholder={tags.length < maxTags ? 'ENTERキーで検索' : `${maxTags}個まで`}
        {...{value, onKeyDown, onKeyUp, onChange, onCompositionStart, onCompositionEnd}}
      />
      <button type='button' className='cancel' onClick={_ => setTags([])} disabled={!tags.length}>
        <img src={icoXCircle} className='icoQuit' />
      </button>
      <button type='button' className='tail' onClick={_ => onSearchButton()}>
        <img src={icoSearch} className='icoSearch' />
      </button>
    </div>
  );
}

interface ITagItemProps extends HTMLAttributes<HTMLDivElement> {
  className?:  string;
  onDeleteCB?: () => void;  // callback when delete the tag
}

/**
 * Tag item
 * @param children tag string
 * @param onDeleteCB callback when closing button clicked - the button will be shown
 *        only when the callback is given
 */
export const TagItem: FC<ITagItemProps> = ({
  children,
  className,
  onDeleteCB,
  ...props
}) => {
  return (
    <div {...{className}} {...props}
      data-k={children?.toString().includes('駅') ? 'station' : ''}
    >
      {children}
      {onDeleteCB &&
      <button type='button' className='tag' onClick={onDeleteCB}>
        <img src={icoXCircle} className='icoClose' />
      </button>}
    </div>
  );
}



  // constants for each render
  // delimeter: whitespace, ',', ';' unique search keys, remove empty string
  // const sKeys = [...new Set(search.trim().split(/[\s,;|]+/).filter(s => s))];
  // if (!noCompo)
  //   sKeys.pop();  // IME編集中なら、最後のキーを捨てる
