/**
 * @file    Sorter
 * @version 0.2.0
 * @Date    2024/06/19
 * @author  TA_金秀
 * ソート対象列の状態（ソート順）を全て維持する必要はないことで、TSortOrder[]を破棄。
 * ----------------------------------------------------------------------
 *  | c0 | c1 | c2 | ... | cN |
 *              ↑ click: activate sort order
 *  - sortCol: current active sort column id, undefined when no active sorts
 *  - sOrder:  sort order (◇▲▼)
 *  sort state = (sortCol, sOrder) ← need to manage this tuple
 *  When the selected column changes, all other columns' sort order should be reset to no sort.
 */
import { useState, } from 'react';
import type { TDataLine, } from 'util/loader';
import type { IHeadInfo, } from 'biz/metro';

export const SORT_ICONS = ['◇', '▲', '▼'];

export const ST_NONE       = undefined;
export const ST_NUMERIC    = 1;
export const ST_STRING     = 2;
export type TSortType  =  typeof ST_NONE
                        | typeof ST_NUMERIC
                        | typeof ST_STRING;
// state 0: none, 1: ascending(順), 2: descending(逆)
export const SO_NONE       = 0;
export const SO_ASCENDING  = 1;
export const SO_DESCENDING = 2;
export type TSortOrder =
    typeof SO_NONE
  | typeof SO_ASCENDING
  | typeof SO_DESCENDING;

type TSortCol = number|undefined;

interface ISortParams {
  sortCol:    TSortCol;      // sort column
  setSortCol: (c: TSortCol) => void;
  sOrder:     TSortOrder;
  setSOrder:  (so: TSortOrder) => void;
}

export const useSorter = (
  head: IHeadInfo[],
  body: TDataLine[],
) => {
  const [sortCol, setSortCol] = useState<TSortCol>(ST_NONE);    // a switch to turn on the sort key
  const [sOrder,  setSOrder]  = useState<TSortOrder>(SO_NONE);  // a switch to turn on the sort key

  if (sortCol !== ST_NONE) {
    /* eslint-disable  @typescript-eslint/no-explicit-any */
    const sign = (sOrder === SO_ASCENDING) ? 1 : -1;
    if (head[sortCol].sort === ST_NUMERIC)  // 検査設備ID
      body.sort((a: any, b: any) => sign*(Number(a[sortCol]) - Number(b[sortCol])));
    else
      // fRes.sort((a: any, b: any) => sign*(a[sortCol] < b[sortCol] ? -1 : 1));
      body.sort((a: any, b: any) => sign*a[sortCol]?.localeCompare(b[sortCol]));
    // console.log('sort:', head[sortCol].name, sortCol, sOrder);
  }
  return ({
    sortCol,
    setSortCol,
    sOrder,
    setSOrder,
  });
}

// set a sort icon for the sortable column's header
export const SpanSort = ({c, sortCol, setSortCol, sOrder, setSOrder}: {c: TSortCol} & ISortParams) =>
  <span className='sortarea'
    onClick={_ev => {
      setSortCol(c);
      setSOrder(c === sortCol ? (sOrder+1) % 3 as TSortOrder : SO_ASCENDING);
    }}
  >
    {SORT_ICONS[c === sortCol ? sOrder : SO_NONE]}
  </span>;

/*
export type TASortOrders = TSortOrder[];
interface ISortParams {
  c:           number|undefined;      // sort column
  aSOrders:    TASortOrders;
  setASOrders: (aS: TASortOrders) => void;
  setSortCol:  (c:  number|undefined) => void;
}

// called onClick on the header
export const setNthSortOrder = (
  c:           number|undefined,      // sort column
  aSOrders:    TASortOrders,
  setASOrders: (aS: TASortOrders) => void,
  setSortCol:  (c:  number|undefined) => void,
) => {
  if (c === undefined) return;
  setASOrders([
    ...aSOrders.slice(0, c) as TSortOrder[],
      (aSOrders[c] + 1) % 3 as TSortOrder,
    ...aSOrders.slice(c+1)  as TSortOrder[]
  ]);
  setSortCol(c);
}

// AppIeq.tsx
  const [sortCol,  setSortCol]  = useState<number|undefined>();  // a switch to turn on the sort key
  const [aSOrders, setASOrders] = useState<TASortOrders>(
                                   [0,1, ...new Array(headIeq.length-2).fill(0)]); // array of sort order status
// AppLtp.tsx
  const [aSOrders, setASOrders] = useState<TASortOrders>(
                                  [1, ...new Array(headLtp.length-1).fill(0)]); // array of sort order status
*/
