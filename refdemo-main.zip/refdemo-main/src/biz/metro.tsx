/**
 * @file    REFMa Final Demo 長期作業計画表 絞り込み検索
 *          Biz logic 業務特有のデータ、ロジック
 * @version 0.1
 * @Date    2024/06/19
 * @author  TA_金秀
 **/
import { type PropsWithChildren, useState, } from 'react';
import { DEBUG, } from 'util/util';
import type { TSortType, } from 'util/sorter';
import type { IComboChoice, } from 'util/combo';
import { ComboChoice, } from 'util/combo';
import { cLo, } from 'util/util';
import 'styles/REFMa-ButtonStyle.css';

import icoEdit     from 'Images/grip_edit.png';
import icoDelete   from 'Images/grip_delete.png';
import icoCopy     from 'Images/grip_copy.png';
import icoDownload from 'Images/arrow-down-tray.svg';
import icoUpload   from 'Images/arrow-up-tray.svg';
import icoUpdate   from 'Images/arrow-path.svg';

export interface IJurisData {
  id:   number;
  line: string;
  ku:   string;
  cls:  string;
}

// 所管区情報
export const JurisData = [  // [M_所管区].所管区ID
  // D: 電機区
  { id: 55, line: '銀座線',           ku: '電機区', cls: 'metroG', },
  { id: 56, line: '丸ノ内線',         ku: '電機区', cls: 'metroM', },
  { id: 57, line: '日比谷線',         ku: '電機区', cls: 'metroH', },
  { id: 58, line: '東西線',           ku: '電機区', cls: 'metroT', },
  { id: 59, line: '千代田線',         ku: '電機区', cls: 'metroC', },
  { id: 60, line: '有楽町・副都心線', ku: '電機区', cls: 'metroY', },
  { id: 61, line: '半蔵門線',         ku: '電機区', cls: 'metroZ', },
  { id: 62, line: '南北線',           ku: '電機区', cls: 'metroN', },
  // S: 信通区
  { id: 63, line: '銀座線',           ku: '信通区', cls: 'metroG', },
  { id: 64, line: '丸ノ内線',         ku: '信通区', cls: 'metroM', },
  { id: 65, line: '日比谷線',         ku: '信通区', cls: 'metroH', },
  { id: 66, line: '東西線',           ku: '信通区', cls: 'metroT', },
  { id: 67, line: '千代田線',         ku: '信通区', cls: 'metroC', },
  { id: 68, line: '有楽町・副都心線', ku: '信通区', cls: 'metroY', },
  { id: 69, line: '半蔵門線',         ku: '信通区', cls: 'metroZ', },
  { id: 70, line: '南北線',           ku: '信通区', cls: 'metroN', },
];

const JN = (jd: IJurisData) => `鉄道本部電気部${jd.ku}_${jd.line}${jd.ku}`;

export const JurisChoices: IComboChoice[] = [...Array(JurisData.length).keys()].map(i =>
  ({ id: JurisData[i].id, name: JN(JurisData[i]), on: true, }));

export const useJuris = () => {
  const [juris, setJuris] = useState<IComboChoice>(JurisChoices[0]);
  return ({juris, setJuris});
}

export const JurisCombobox = ({juris, setJuris}: {
  juris:    IComboChoice;
  setJuris: (v: IComboChoice) => void;
}) =>
  <ComboChoice choices={JurisChoices} value={juris} setValue={setJuris} label='・所管区' />;

// REST API: csv file server
// DEBUG mode will need a nodejs file server.
const URL_ROOT = DEBUG ? 'http://localhost:9001/assets/' : '/assets/';

export const bizUrls = {
  Ieq:      (id: number) => `${URL_ROOT}Ledger/Ieq/ie${id}.csv`, 
  LtpInsp:  (id: number) => `${URL_ROOT}LongTermPlan/insp${id}.csv`, 
  LtpPlans: (id: number) => `${URL_ROOT}LongTermPlan/plans/plans${id}.csv`, 
}

export const JurisDisp = ({jurisId}: { jurisId: number; }) => {
  const jd = JurisData.find(x => x.id === jurisId);
  return jd
  ? <>
      所管区：鉄道本部電気部{jd.ku}_
      <JurisLine {...{jurisId}} />
    </>
  : null;
}

export const JurisLine = ({jurisId}: { jurisId: number; }) => {
  const jd = JurisData.find(x => x.id === jurisId);
  return jd
  ? <>
      <span className={jd.cls}>{jd.line}</span>{jd.ku}
    </>
  : null;
}

const APRV_ST = [  // approval states
  '',
  '承認依頼中',
  '承認完了',
  '差戻し',
  '依頼取消',
];

export const aprvId = (v?: string|number|null) => {
  const id = (typeof v === 'string') ? APRV_ST.indexOf(v) : -1;
  return (id >= 0) ? id : undefined;
}

// common codes
export const aprvStatus = (id: string|number|null) => {  // approval status 承認状態
  if (!id)
    return id;
  const idN = Number(id);
  return (idN < APRV_ST.length) ? APRV_ST[idN] : null;
}

export const nextJuris = (jurisId: number) =>
  JurisChoices[(jurisId - JurisChoices[0].id + 1) % JurisChoices.length];
/*
// 検査設備台帳
const dspHead = [  // display header
  '状態',
  '検査設備ID',
  '検査設備名',
  '設置場所', 
  '設置場所(計画表示用)',
  '所管区',
  '設備カテゴリ',  // '組織区分', 'レベル1～5'
  '休止期間', 
  '廃止日',
  '最終更新日',
  '最終更新者',
];
*/
/*
interface IeqBody {  // Inspection Equipment Body element
  Status:                   string; // 0. 状態
  InspectionEquipmentId:    number; // 1. 検査設備ID
  InspectionEquipmentName:  string; // 2. 検査設備名
  InstallPlace:             string; // 3. 設置場所
  InstallPlaceDsp:          string; // 4. 設置場所(計画表示用)
  Jurisdiction:             string; // 5. 所管区
  SosikiKubun:              string; // 6. 組織区分
  Level1:                   string; // 7. レベル1
  Level2:                   string; // 8. レベル2
  Level3?:                  string; // 9. レベル3
  Level4?:                  string; // 10.レベル4
  Level5?:                  string; // 11.レベル5
  RestPeriod?:              string; // 12.休止期間
  AbolishDate?:             string; // 13.廃止日
  UpdateDate:               string; // 14.最終更新日
  UpdateUser?:              string; // 15.最終更新者
}
*/

export interface IHeadInfo {  // Sortable Header element
  id?:     number;  // data (body portion) column number
  name:    string;
  rs?:     number;  // rowSpan
  cs?:     number;  // colSpan
  sort?:   TSortType;  // sort type (1: number, 2: string, )
  level?:  number;  // display level (1: default, highest priority)
  cls?:    string;  // className
}

// Controls data definition
const REFMaLinks = {
  edit:   { label: '編集',  img: <img src={icoEdit}   className='icon' />, },
  delete: { label: '削除',  img: <img src={icoDelete} className='icon' />, },
  copy:   { label: '複写',  img: <img src={icoCopy}   className='icon' />, },
}

interface IREFMaBtnParam {
  className?: string;
  onClick?:   () => void;
}

export const REFMaIcon = ({ action, className, onClick, }: {
  action: keyof typeof REFMaLinks;
} & IREFMaBtnParam) =>
  <a {...(className && {className})} {...(onClick && {onClick})}>
    {REFMaLinks[action].img}
  </a>;

export const REFMaBtn = ({className, onClick, children}: PropsWithChildren<IREFMaBtnParam>) =>
  <a {...cLo('button', className)} {...(onClick && {onClick})}>
    {children}
  </a>;

export const REFMaBtnDownload = ({className, onClick}: IREFMaBtnParam) =>
  <REFMaBtn {...cLo('icon', className)} {...{onClick}}>
    <img src={icoDownload} className='svgIcon' />
  </REFMaBtn>;

export const REFMaBtnUpload = ({className, onClick}: IREFMaBtnParam) =>
  <REFMaBtn {...cLo('icon', className)} {...{onClick}}>
    <img src={icoUpload} className='svgIcon' />
  </REFMaBtn>;

export const REFMaBtnUpdate = ({className, onClick}: IREFMaBtnParam) =>
  <REFMaBtn {...cLo('icon', className)} {...{onClick}}>
    <img src={icoUpdate} className='svgIcon' />
  </REFMaBtn>;

export const REFMaBtnDispUpdate = ({onClick, fetchTs, reload}: IREFMaBtnParam & {
  fetchTs: Date|undefined,
  reload:  number,
}) =>
  <>
    <REFMaBtn {...{onClick}}>表示更新</REFMaBtn>
    {fetchTs &&
    <span className='fetchTs'>
      <span className='reload'>{reload}</span>
      {fetchTs.toLocaleString()}
    </span>}
  </>
;

