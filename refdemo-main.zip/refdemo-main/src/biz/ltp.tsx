/**
 * @file    REFMa 長期作業計画
 * @version 0.1
 * @Date    2024/06/19
 * @author  TA_金秀
 **/
import type { PropsWithChildren, } from 'react';
// import { useState, } from 'react';
import type { IDataMapper, } from 'util/loader';
import { xNULL, } from 'util/loader';
import type { IHeadInfo, } from 'biz/metro';
import { JurisLine, } from 'biz/metro';
import { ST_STRING, ST_NUMERIC, } from 'util/sorter';
// import { ModalDlg, } from 'util/ux';

// select and transform
// 長期作業計画 LongTermPlan

export const headLtp: IHeadInfo[] = [  // no rowSpan
  { name:'検査ID',               sort:ST_NUMERIC, },
  // 既存画面
  { name:'組織区分',             sort:ST_STRING, },
  { name:'検査設備名',           sort:ST_STRING, },
  { name:'周期',                 sort:ST_STRING, },
  { name:'作業コード',           sort:ST_STRING, },
  { name:'場所',                 sort:ST_STRING, },
  { name:'実施主体',             sort:ST_STRING, },
  { name:'計画策定に関する備考', sort:ST_STRING, },
  // 追加項目
  { name:'検査補足名称',         sort:ST_STRING, },
  { name:'補足',                 sort:ST_STRING, },
  { name:'承認に関する備考',     sort:ST_STRING, },
  { name:'補足(定期検査ひな型)', sort:ST_STRING, },
  { name:'補足(検査設備台帳型)', sort:ST_STRING, },
  { name:'変更理由',             sort:ST_STRING, },
];

// map csv raw data to display data
// SQLクエリ結果のcsvファイルから、行毎に画面表示に使う項目へ変換する処理の定義
export const selectLtpInsp: IDataMapper = (r) =>
[
  r[2],
  // 既存画面
  r[52],
  r[47],
  r[60],
  r[103],
  r[77],
  r[39],
  r[17],
  // 追加項目
  r[4],
  r[15],
  r[18],
  r[50],
  r[90],
  r[102],
  // 既存検索 
  /*
  r[5],
  aprvStatus(r[33]),  // 状態
  r[0],
  r[1],
  r[35]+'・'+r[36],
  r[4],
  r[44]+'_'+r[46],
  r.slice(37,42).filter(x => x !== 'NULL' && x).join('-'),
  r[12] === 0 ? null : r[13]+'～'+r[14],  // 休止期間
  r[10] === 0 ? null : r[11],             // 廃止日
  r[21],
  r[48] === 'NULL' ? null : r[48],
  */
];

export const transformLtpInsp: IDataMapper = (r) =>
  r.map(v => xNULL(v));

// temporal
export const SearchConditionsLtp = ({jurisId, children}: PropsWithChildren<{ jurisId: number; }>) =>
  <div className='SearchConditions'>
    <p className='SCLabel'>検索条件</p>
    所管区変更日：2020/04/01 <JurisLine {...{jurisId}} />
    {children}
  </div>;

export const headClass = (c: number) =>
  headLtp[c].cls && {className: headLtp[c].cls};
