/**
 * @file    REFMa 検査設備一覧画面、MVC化に伴う画面側の実験
 * @version 1.1.0
 * @Date    2024/05/29
 * @author  TA_金秀
 * 2024/06/18 JSON → CSV、Object → Array of items
 */
import { useState, Suspense, } from 'react';
import type { IDropdownMenuItem, } from 'util/ux';
import { LabeledSwitch, useTimedMsg, Alert, Noti,
  SlideOver, ModalDlg, CheckV,
} from 'util/ux';
import { useSearch, SearchInput, HiTags, } from 'util/search';
import { usePager, Pager, } from 'util/pager';
import { Resizable, } from 'util/resizable';
import { useLoadParseData, } from 'util/loader';
import { useSorter, SpanSort, } from 'util/sorter';
import { JurisCombobox, nextJuris, useJuris, bizUrls, aprvId,
  REFMaIcon,
  REFMaBtn,
  REFMaBtnDownload,
  REFMaBtnUpload,
  REFMaBtnUpdate,
  REFMaBtnDispUpdate,
} from 'biz/metro';
import {
  selectIeq, transformIeq, markupIeq, headIeq, headInfoIeq, MarkupText,
  headClass, IeqDetail, SearchConditionsIeq,
} from 'biz/ieq';
import 'styles/App.css';
// import { cLoIf, } from './util';
// import bodyRaw  from './assets/Ledger/equipment16銀座線電機区.json';
//import DataInspection from './assets/inspection43.json';

function AppIeq() {
  const dispLevels   = ['1', '2', '3'];
  const rowsPP = [10,20,50,100,200,500,1000,2000];  // rows per page selection list
  const menu: IDropdownMenuItem[] = [  // target scope
    {label:'すべて',    on: (s: number) => console.log(menu[s].label),},
    {label:'表示項目',  on: (s: number) => console.log(menu[s].label),},
    {label:'条件設定▷', on: (s: number) => console.log(menu[s].label),},
  ];
  // states
  const [dispLv,  setDispLv]  = useState(dispLevels[dispLevels.length-1]);
  // refactoring: to reduce rendering later change with ... and localize rendering of search and <input>
  const [markup,  setMarkup]  = useState(false); // turn on/off markup text
  const [slide,   setSlide]   = useState(0);     // active 検査設備ID
  const [slideOn, setSlideOn] = useState(false);
  const [dlg,     setDlg]     = useState(0);     // active 検査設備ID
  const [dlgOn,   setDlgOn]   = useState(false);
  const [reload,  setReload]  = useState(1);     // fetch count to force reload
  const [fetchTs, setFetchTs] = useState(new Date());  // timestamp
  const [throtle, setThrotle] = useState(true);
  const {
    msg:      alert,
    setMsg:   setAlert,
    setMsgMs: setAlertMs,
  } = useTimedMsg();
  const {
    msg:      noti,
    setMsg:   setNoti,
    setMsgMs: setNotiMs,
  } = useTimedMsg();

  const onFetchStart = (ts: Date) => {  // callback on fetch start
    setFetchTs(ts);
    setAlert(`データ受信中 ${ts.toLocaleString()}`);
  }
  //************************************************************************************
  const {juris, setJuris} = useJuris();                             // 1. 所管区選択
  const {bodyRaw} = useLoadParseData(                               // 2. データロード
    reload,                     // fetch reload count
    bizUrls.Ieq(juris.id),      // url
    selectIeq,                  // select:    使用する列の選択
    transformIeq,               // transform: 変換処理
    throtle ? 1000 : 0,         // delay(ms) effect
    setAlert,                   // onError
    onFetchStart,               // onStart
    () => setAlert(''),         // onEnd
  );
  // データ加工処理 rules for display / markup - run for each render
  const mkupIeq = markup && bodyRaw.length                          // 3. データ加工 markup
    ? bodyRaw.map(r => markupIeq(r))
    : bodyRaw;
  const {fRes, ...srchR}      = useSearch(menu, mkupIeq);           // 4. 検索
  const sortR                 = useSorter(headIeq, fRes);           // 5. ソート
  const {fResPaged, ...pageR} = usePager(fRes, rowsPP[3], rowsPP);  // 6. ページング
  //************************************************************************************
  // console.log(tags);  // check rendering occurrences w.r.t. the user key inputs
  // fRes.forEach(r => r.forEach(c => HiTags(tags, c)));

  // const show = (level: number|undefined) => !level || (level <= Number(dispLv));

  // [...Array(maxPage).keys()] ⇒ 0..(maxPage-1)
  // .filter(p => (maxPage <= 20) ? p : (p <= 11 || p === page || p >= (maxPage-10)))
  // .map(p => (maxPage > 20 && p === 11) 
  const PageControls = () =>
    <Pager {...pageR}>
      <label>
        ■表示ﾚﾍﾞﾙ
        <select value={dispLv} onChange={ev => setDispLv(ev.target.value)}>
          {dispLevels.map((_op, k) => <option key={k}>{dispLevels[k]}</option>)}
        </select>
      </label>
    </Pager>;

  return (
    <div className='spa_demo ieq'>
      <SearchConditionsIeq jurisId={juris.id}>
        <JurisCombobox {...{juris, setJuris}} />
        <REFMaBtnDispUpdate {...{fetchTs, reload}}
          onClick={() => setReload(reload + 1)}
        />
        <CheckV checked={throtle} setChecked={setThrotle} />
        <span className='text-sm'>遅延</span>
      </SearchConditionsIeq>
      <SlideOver show={slideOn} setShow={setSlideOn} title='検査設備台帳詳細'>
        <IeqDetail body={fRes} id={slide} />
      </SlideOver>
      <ModalDlg  show={dlgOn} setShow={setDlgOn} title='検査設備台帳編集'>
        <IeqDetail body={fRes} id={dlg} />
      </ModalDlg>
      <Noti  {...{setNoti}}>{noti}</Noti>
      <Alert {...{setAlert}}>{alert}</Alert>
      <div className='SControls top'>
        <REFMaBtn className='navigate-search'
          onClick={() => setNotiMs(noti ? '' : '検索実装中', 3000)}
        >
          検索
        </REFMaBtn>
        <REFMaBtnDownload onClick={() => setNotiMs(noti ? '' : '通知試験中、デモ用です。', 3000)} />
        <REFMaBtnUpload   onClick={() => setAlertMs(alert ? '' : 'アラート試験中', 3000)} />
        <REFMaBtnUpdate   onClick={() => setJuris(nextJuris(juris.id))} />
        <SearchInput {...srchR}>
          <LabeledSwitch enable={markup} setEnable={setMarkup}>縮約</LabeledSwitch>
        </SearchInput>
      </div>
      <PageControls />

      <Suspense fallback={<p className='loading'>Loading ... </p>}>
      {bodyRaw.length
      ? <table className={'ieq level' + dispLv}>
          <thead>
          {headInfoIeq.map((rows, r) =>
            <tr key={r}>
            {rows.map((hc, c) =>
              <Resizable key={c}>
              {({ref}) => (
                <th
                  data-lv={hc.level || '1'}
                  {...(hc.rs && {rowSpan: hc.rs})}
                  {...(hc.cs && {colSpan: hc.cs})}
                >
                  {hc.name}
                  {hc.sort && <SpanSort c={hc.id} {...sortR} />}
                  <span className='resizer' {...{ref}} />
                </th>)}
              </Resizable>)}
            </tr>)}
          </thead>
          <tbody>
          {fResPaged.map(rec =>
            <tr key={rec[1]}>
              <td>
                <REFMaIcon action='edit'
                    onClick={() => {
                      setDlg(rec[1] as number);
                      setDlgOn(true);
                    }}
                />
              </td>
              {rec.map((col, i) =>
                <td key={i}
                  {...((i === 0) && {'data-aprv': aprvId(col),
                      onClick: () => {
                        setSlide(rec[1] as number);
                        setSlideOn(true);
                      }})}
                  {...headClass(i)}
                >
                  {markup
                  ? MarkupText(col, headIeq[i].cls, srchR.hi ? srchR.tags : undefined)
                  : srchR.hi ? HiTags(srchR.tags, col) : col}
                </td>)}
              <td><REFMaIcon action='delete' /></td>
              <td><REFMaIcon action='copy'   /></td>
            </tr>)}
          </tbody>
        </table>
      : null}
      </Suspense>
      <div className='SControls bottom'>
        <REFMaBtn onClick={() => {
            srchR.setTags(['渋谷駅','外苑前','配線','新橋','表参道','青山','ケーブル']);
            setAlertMs('デモ用の検索キーワード自動入力', 3000);
          }}
        >
          追加
        </REFMaBtn>
      </div>
    </div>
  );
}
// ? fRes.filter((_, r) => r >= (page - 1)*rowsPage && r < page*rowsPage)

export default AppIeq;

/*
  const TH = ({rowSpan, colSpan, children}: PropsWithChildren<{
    rowSpan?: number;
    colSpan?: number; 
  }>) =>
    <th {...(rowSpan && {rowSpan})} {...(colSpan && {colSpan})} onClick={() => alert({children})}>{children}</th>;
  
  const TD = ({children}: PropsWithChildren) => <td>{children}</td>;
    children
    ? <td>{HighlightText(children.toLocaleString(), search)}</td>
    : <td></td>;
*/
