/**
 * @file    REFMa Final Demo 長期作業計画表 絞り込み検索
 * @version 0.1
 * @Date    2024/06/17
 * @author  TA_金秀
 **/
import { useState, Suspense, } from 'react';
import type { IDropdownMenuItem, } from 'util/ux';
import { useTimedMsg, Alert, Noti, CheckV, ModalDlg, } from 'util/ux';
import { useSearch, SearchInput, HiTags, } from 'util/search';
import { Pager, usePager, } from 'util/pager';
import { Resizable, } from 'util/resizable';
import { useLoadParseData, } from 'util/loader';
import { JurisCombobox, nextJuris, bizUrls, useJuris,
  REFMaBtn, REFMaBtnDispUpdate,
} from 'biz/metro';
import { headLtp, selectLtpInsp, transformLtpInsp, headClass,
  SearchConditionsLtp,
} from 'biz/ltp';
import { useSorter, SpanSort, } from 'util/sorter';
import 'styles/App.css';

function AppLtp() {
  const [reload,  setReload]  = useState(1);      // fetch count to force reload
  const [fetchTs, setFetchTs] = useState(new Date());  // timestamp
  const [throtle, setThrotle] = useState(true);   // 遅延効果
  const [iniAprv, setIniAprv] = useState(false);  // 初回承認情報表示
  const [dlg,   setDlg]       = useState(0);     // active 検査設備ID
  const [dlgOn, setDlgOn]     = useState(false);
  const rowsPP = [50,100,200,300,400,500,1000];
  const menu: IDropdownMenuItem[] = [  // target scope
    {label:'すべて',     on: (s: number) => console.log(menu[s].label),},
    {label:'表示項目',   on: (s: number) => console.log(menu[s].label),},
    {label:'作業コード', on: (s: number) => console.log(menu[s].label),},
    {label:'計画策定に関する備考', on: (s: number) => console.log(menu[s].label),},
    {label:'条件設定▷',  on: (s: number) => { setDlg(s); setDlgOn(true); },}
  ];
  const {
    msg:      alert,
    setMsg:   setAlert,
    setMsgMs: setAlertMs,
  } = useTimedMsg();
  const {
    msg:      noti,
    setMsg:   setNoti,
    setMsgMs: setNotiMs,
  } = useTimedMsg();

  const onFetchStart = (ts: Date) => {  // callback on fetch start
    setFetchTs(ts);
    setAlert(`データ受信中 ${ts.toLocaleString()}`);
  }
  //************************************************************************************
  const {juris, setJuris} = useJuris();                             // 1. 所管区選択
  // rendering毎にデータ変換処理を行うことは負荷が掛かるため、
  // 最初データロード時にデータ変換処理を済ませておく。
  const {bodyRaw} = useLoadParseData(                               // 2. データロード
    reload,                     // fetch reload count
    bizUrls.LtpInsp(juris.id),  // url
    selectLtpInsp,              // select:    使用する列の選択
    transformLtpInsp,           // transform: 変換処理
    throtle ? 1500 : 0,         // delay ms
    setAlert,                   // onError callback
    onFetchStart,               // onStart
    () => setAlert(''),         // onEnd
  );
  // no markup                                                      // 3. データ加工 markup
  const {fRes, ...srchR}      = useSearch(menu, bodyRaw);           // 4. 検索
  const sortR                 = useSorter(headLtp, fRes);           // 5. ソート
  const {fResPaged, ...pageR} = usePager(fRes, rowsPP[1], rowsPP);  // 6. ページング
  //************************************************************************************

  const REFMaButtons: {label: string; cls?: string; on?: () => void;}[] = [
    {label:'検索',          cls:'navigate-search', on: () => setNotiMs(noti ? '' : '検索実装中', 3000),},
    {label:'編集',          cls:'navigate-save',},
    {label:'計画更新',      cls:'aspNetDisabled'},
    {label:'承認依頼',      cls:'navigate-save aspNetDisabled', on: () => setJuris(nextJuris(juris.id)),},
    {label:'承認依頼取消',  cls:'aspNetDisabled'},
    {label:'承認関連', },
    {label:'長期作業計画表', },
    {label:'変更履歴', },
  ];

  // Array.prototype.slice(start, end)
  // <span className='col-id'>{i}</span>{c}</th>
  return (
    <div className='spa_demo ltp'>
      <SearchConditionsLtp jurisId={juris.id}>
        <JurisCombobox {...{juris, setJuris}} />
        <REFMaBtnDispUpdate {...{fetchTs, reload}}
          onClick={() => setReload(reload + 1)}
        />
        <CheckV checked={throtle} setChecked={setThrotle} />
        <span className='text-sm'>遅延</span>
      </SearchConditionsLtp>
      <Alert {...{setAlert}}>{alert}</Alert>
      <Noti {...{setNoti}}>{noti}</Noti>
      <ModalDlg  show={dlgOn} setShow={setDlgOn} title='検索条件設定'>
        てすと{dlg}
      </ModalDlg>
      <div className='SControls top'>
        {REFMaButtons.map(m =>
          <REFMaBtn key={m.label}
            {...(m.cls && {className: m.cls})}
            {...(m.on
                ? {onClick: m.on}
                : {onClick: () => setNotiMs(m.label, 3000)})}
          >
            {m.label}
          </REFMaBtn>)}
        <div className='text-xs flex items-center gap-0.5'>
          <CheckV checked={iniAprv}
            setChecked={() => {
              const nextIniAprv = !iniAprv;
              setNotiMs(`初回承認情報表示 ${nextIniAprv ? 'する' : 'しない'}`, 5000);
              setIniAprv(!iniAprv);
            }}
          />
          初回承認情報表示
        </div>
      </div>
      <SearchInput {...srchR}>
        reserved
      </SearchInput>
      <Pager {...pageR}>
        <REFMaBtn className='aspNetDisabled'>
          一覧出力
        </REFMaBtn>
      </Pager>
      <Suspense fallback={<h1>Loading...</h1>}>
      {bodyRaw?.length
      ? <table className='ltp'>
          <thead>
            <tr>
            {headLtp.map((hc, c) =>
              <Resizable key={c}>
              {({ref}) =>
                <th key={c}>
                  {hc.name}
                  {hc.sort && <SpanSort {...{c}} {...sortR} />}
                  <span className='resizer' {...{ref}} />
                </th>}
              </Resizable>)}
            </tr>
          </thead>
          <tbody>
          {fResPaged.map(rec =>
            <tr key={rec[0]}>
            {rec.map((col, i) =>
              <td key={i} {...headClass(i)}>
                {srchR.hi ? HiTags(srchR.tags, col) : col}
              </td>)}
            </tr>)}
          </tbody>
        </table>
      : null}
      </Suspense>
      <div className='SControls bottom'>
        <REFMaBtn onClick={() => {
            srchR.setTags(['絶縁抵抗','渋谷駅','PED01','PPA33','トンネル','検査基準日平準化','ケーブル']);
            setAlertMs('デモ用の検索キーワード自動入力', 3000);
          }}
        >
         検索テスト 
        </REFMaBtn>
      </div>
    </div>
  );
}

export default AppLtp;
