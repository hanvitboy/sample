/**
 * @file    REFMa 検査設備一覧画面、MVC化に伴う画面側の実験
 * @version 1.0.0
 * @Date 2024/05/29
 * @author  TA_金秀
 */
import { useState, } from 'react';
// import reactLogo from './assets/react.svg'
import icoEdit from './Images/grip_edit.png';
import icoDelete from './Images/grip_delete.png';
import icoCopy from './Images/grip_copy.png';
import './App.css';
// import { cLoIf, } from './util';
import DataEquipment  from './assets/equipment16.json';
//import DataInspection from './assets/inspection43.json';

// text: source text
// highlight: substring to be highlighted
function HighlightText(text: string0U, highlight: string) {
  // Split on highlight term and include term into parts, ignore case
  if (!text)
    return null;
  if (!highlight)
    return (<>{text}</>);
  const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
  return (parts &&
    <>{parts.map((part, i) => 
        (part === highlight)
          ? <span key={i} className='hi'>{ part }</span>
          : part)}
    </>);
}
/*
interface IEquipment {
  Status:                   string; // 状態
  InspectionEquipmentId:    number; // 検査設備ID
  InspectionEquipmentName:  string; // 検査設備名
  InstallPlace:             string; // 設置場所
  
}
*/

interface IeqHCol {
  id?:     number;  // column number
  name:    string;
  rs?:     number;  // rowSpan
  cs?:     number;  // colSpan
  level?:  number;  // display level (1: default)
  nosort?: boolean; // not sortable
  hlink?:  boolean; // hyperlink
}

// Inspection Equipment Header Columns
// Columns with id will be the search target
const eqH: IeqHCol[][] = [
  [  // 表ヘッド、行毎
    {         name: '',                     rs: 2, nosort: true },  // 鉛筆アイコン
    { id: 0,  name: '状態',                 rs: 2, hlink: true },
    { id: 1,  name: '検査設備ID',           rs: 2 },
    { id: 2,  name: '検査設備名',           rs: 2 },
    { id: 3,  name: '設置場所',             rs: 2, level: 3 },

    { id: 4,  name: '設置場所(計画表示用)', rs: 2 },
    { id: 5,  name: '所管区',               rs: 2, level: 3 },
    {         name: '設備カテゴリ',         cs: 6, level: 2, nosort: true },  // 上位ヘッダー
    { id: 12, name: '休止期間',             rs: 2 },
    { id: 13, name: '廃止日',               rs: 2 },

    { id: 14, name: '最終更新日',           rs: 2 },
    { id: 15, name: '最終更新者',           rs: 2, level: 3 },
    {         name: '',                     rs: 2, nosort: true },  // 削除アイコン
    {         name: '複写',                 rs: 2, nosort: true },
  ],
  [  // 2行目
    { id: 6,  name: '組織区分', level: 2 },  // uppper colSpan should also be varied!
    { id: 7,  name: 'レベル1',  level: 2 },
    { id: 8,  name: 'レベル2',  level: 2 },
    { id: 9,  name: 'レベル3',  level: 2 },
    { id: 10, name: 'レベル4',  level: 2 },
    { id: 11, name: 'レベル5',  level: 2 },
  ]];

// Display level logic moved to CSS for better performance (fewer changes in DOM per rendering)
/*
const contDL = [  // content display level
//  eqH[0][0].level,  // edit icon, no data
  eqH[0][1].level,
  eqH[0][2].level,
  eqH[0][3].level,
  eqH[0][4].level,

  eqH[0][5].level,
  eqH[0][6].level,
  eqH[1][0].level,
  eqH[1][1].level,
  eqH[1][2].level,

  eqH[1][3].level,
  eqH[1][4].level,
  eqH[1][5].level,
  eqH[0][8].level,
  eqH[0][9].level,

  eqH[0][10].level,
  eqH[0][11].level,
//  eqH[0][12].level,  // delete icon, no data
//  eqH[0][13].level,  // copy icon, no data
];
*/

const TopControls = () =>
  <div className='EquipTopControls'>
    <a className='button navigate-search' onClick={() => alert('検索画面作成中')}>検索</a>
    <a className='button' onClick={() => alert('ダウンロード')}>ダウンロード</a>
    <a className='button' onClick={() => alert('アップロード')}>アップロード</a>
    <a className='button' onClick={() => alert('作成中')}>表示更新</a>
  </div>;

const BottomControls = () =>
  <div className='EquipBottomControls'>
    <a className='button' onClick={() => alert('追加')}>追加</a>
  </div>;

const IcoEdit = () =>
  <a href="javascript: alert('編集')">
    <img src={icoEdit} className="icon" alt="編集" />
  </a>;
const IcoDelete = () =>
  <a href="javascript: alert('削除')">
    <img src={icoDelete} className="icon" alt="削除" />
  </a>;
const IcoCopy = () =>
  <a href="javascript: alert('複写')">
    <img src={icoCopy} className="icon" alt="複写" />
  </a>;

function App() {
  // const [nowrap, setNowrap] = useState(false);  // too heavy
  //  ? <td className={nowrap ? 'nowrap' : 'wrap'}>{HighlightText(children.toLocaleString(), searchKey)}</td>
  /*
        <label>
          <input type='checkbox' checked={!nowrap} onChange={_ev => setNowrap(!nowrap)} />
          折り返し
        </label>
  */
  const dispLevels = ['1', '2', '3'];
  const [dispLv,    setDispLv]    = useState(dispLevels[dispLevels.length-1]);
  const [searchKey, setSearchKey] = useState('');
  const [highlight, setHighlight] = useState(true);
  const [sortCol,   setSortCol]   = useState<number|undefined>();
  const [sortOrder, setSortOrder] = useState([0,1,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0]);
  /*
  const [noCompo, setNoCompo] = useState(true);  // not in IME composition mode
  
  const handleCompositionStart = () => setNoCompo(false);
  const handleCompositionEnd = () => setNoCompo(true);
            onCompositionStart={handleCompositionStart}
            onCompositionEnd={handleCompositionEnd}
  */
  
/*
  const TH = ({rowSpan, colSpan, children}: PropsWithChildren<{
    rowSpan?: number;
    colSpan?: number; 
  }>) =>
    <th {...(rowSpan && {rowSpan})} {...(colSpan && {colSpan})} onClick={() => alert({children})}>{children}</th>;
  
  const TD = ({children}: PropsWithChildren) => <td>{children}</td>;
    children
    ? <td>{HighlightText(children.toLocaleString(), searchKey)}</td>
    : <td></td>;
  */
    
  const filteredResult = searchKey
    ? DataEquipment.filter(d => Object.values(d).some(c => c?.toString().includes(searchKey)))
    : DataEquipment;

  // useEffect(() => {
  if (sortCol !== undefined) {  // sort column is set
    const so = sortOrder[sortCol];
    if (so) {  // sort order == 0 means no sort
      const isNumeric = sortCol === 1;

      if (sortOrder[sortCol] === 1) {
        if (isNumeric)  // 検査設備ID
          filteredResult.sort((a: any, b: any) => Number(a[sortCol]) - Number(b[sortCol]));
        else
          filteredResult.sort((a: any, b: any) => a[sortCol] < b[sortCol] ? -1 : 1);
        // console.log("Sorted(N):", i);
      } else if (so === 2) {
        if (isNumeric)
          filteredResult.sort((a: any, b: any) => Number(b[sortCol]) - Number(a[sortCol]));
        else
          filteredResult.sort((a: any, b: any) => a[sortCol] < b[sortCol] ? 1 : -1);
        // console.log("Sorted(R):", i);
      }
    }
  }
  // }, [sortCol, JSON.stringify(sortOrder)]);  // TODO check

  // const show = (level: number|undefined) => !level || (level <= Number(dispLv));

  // sort orders 0: none, 1: normal, 2: reverse
  const SortIcon = (id?: number) =>
    ['', '↓', '↑'][(id === undefined) ? 0 : sortOrder[id!]];

  const setNthSortOrder = (n?: number) => {
    if (n !== undefined)
      setSortOrder([...sortOrder.slice(0, n), (sortOrder[n] + 1) % 3, ...sortOrder.slice(n+1)]);
  }
  // console.log(sortOrder);

  const tdClass = (i: number, v?: string|number|null) => {
    if (i === 0) {  // 状
      if (v === '承認依頼中')  return 'request';
      if (v === '差戻し')      return 'remand';
      if (v === '依頼取消')    return 'cancel';
    }
    return '';
  }

  return (
    <div className='m1'>
      <div className='SearchConditions'>
        <p className='SCLabel'>検索条件</p>
        <p className='SCText'>所管区変更日：2020/04/01　所管区：鉄道本部電気部電機区_銀座線電機区　表示件数：1000件</p>
      </div>
      <div className='TopContainer'>
        <TopControls />
        <div className='EquipControls'>
          <label className='nowrap'>
            項目表示レベル
            <select value={dispLv} onChange={ev => setDispLv(ev.target.value)}>
              {dispLevels.map((_op, k) => <option key={k}>{dispLevels[k]}</option>)}
            </select>
            まで
          </label>
          <div className='nowrap'>
            <input type="text"
              value={searchKey}
              onChange={ev => setSearchKey(ev.target.value)}
              placeholder="絞り込み検索"
            />
            <button onClick={_ev => setSearchKey('')} disabled={!searchKey}>X</button>
          </div>
          <div className='nowrap'>
            該当件数：<span className='matchCount'>{filteredResult.length}</span>/{DataEquipment.length}件
          </div>
          <label className='nowrap'>
            <input type='checkbox'
              checked={highlight}
              onChange={_ev => setHighlight(!highlight)} />
            ハイライト
          </label>
        </div>
      </div>
      <div className='TableContainer'>
        <table className={'m1tbl level' + dispLv}>
          <thead>
            {eqH.map((rows, r) =>
              <tr key={r}>
                {rows.map((cols, c) => // show(cols.level) &&
                  <th key={c}
                    data-lv={cols.level  || '1'}
                    {...(cols.rs && {rowSpan: cols.rs})}
                    {...(cols.cs && {colSpan: cols.cs})}
                    {...(cols.nosort && {class: 'nosort'})}
                    {...(!cols.nosort && { onClick : _ev => { setSortCol(cols.id); setNthSortOrder(cols.id); } })}
                  >{cols.name + SortIcon(cols.id)}</th>)}
              </tr>)}
          </thead>
          <tbody>
            {(filteredResult.length > 0 ? filteredResult : DataEquipment)
            .map((rec, k) =>
              <tr key={k}>
                <td><IcoEdit /></td>
                {Object.values(rec).map((v, i) => // show(contDL[i]) &&
                  <td key={i}
                    {...((i === 0) && {class: tdClass(i, v)})}
                  >
                    {(highlight && searchKey)
                      ? HighlightText(v?.toString(), searchKey)
                      : v}
                  </td>)}
                <td><IcoDelete /></td>
                <td><IcoCopy /></td>
              </tr>)}
          </tbody>
        </table>
      </div>
      <BottomControls />
    </div>
  )
}

export default App;
