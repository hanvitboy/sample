# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default {
  // other rules...
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: ['./tsconfig.json', './tsconfig.node.json'],
    tsconfigRootDir: __dirname,
  },
}
```

- Replace `plugin:@typescript-eslint/recommended` to `plugin:@typescript-eslint/recommended-type-checked` or `plugin:@typescript-eslint/strict-type-checked`
- Optionally add `plugin:@typescript-eslint/stylistic-type-checked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and add `plugin:react/recommended` & `plugin:react/jsx-runtime` to the `extends` list

デモ版（【検査設備台帳の画面プロトタイプ】　v03（2024/05/31）
・初期版からの修正内容（重要度順）
1. 「列ソート」の不安定、性能問題のバグ修正、ソート可能列はマウスオーバーで強調表示
2. 「表示レベル」によるテーブルヘッダーの色分けと性能改善（濃い色ほど表示優先度高）
3. スクロールバーの問題解決（メインの枠にコンテンツが収まって内部のスクロールバーのみ表示されるように）
4. 承認状態の背景色（作業実績画面の仕様に従って彩色）
5. ボタン、リンク表示、アイコン等の飾り追加
6. REFMa画面メニューとヘッダー部のレイアウトの偽装
7. リンク先が戻られない所に飛ばされるバグ修正⇒アイコン、ボタン押下でメッセージ画面出力
 
・間に合えなかった機能
1. テーブルの幅をマウスで調整
2. 自動ページング
3. マルチ検索キーワード（空白で区切り、色分け）
4. マウスオーバーでツールチップ表示
5. 検索機能の強化（キーワードのAND, OR, EXCLUDEなど）

等々、フロントエンドだけ切り離して開発展開するメリットをデモしたいものはもっと沢山ありますが、
今回は、Web Forms + MVCの環境下で使用可能なフロントエンド技術をまず調べる必要があったため、
モダンなJavaScriptのジェネリックな機能のみで、ライブラリは使わず派手な演出ができませんでした。
開発ツールの連携ができない非効率はありますが、
MVC化でモダンなフロントエンド機能のデプロイが可能になることが確認できたのは収穫だと思います。
